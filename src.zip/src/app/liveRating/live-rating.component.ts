import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-live-rating',
  templateUrl: './live-rating.component.html',
  styleUrls: ['./live-rating.component.css']
})
export class LiveRatingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
